package com.example.pruebareel

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class YoutubeShortsTimeBlockerService : AccessibilityService() {

    private val MAX_TIME_MS = 5_000L // 5 segundos

    private var inShorts = false
    private var startTime = 0L

    private val handler = Handler(Looper.getMainLooper())
    private var checkerRunning = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.packageName != "com.google.android.youtube") return

        val root = rootInActiveWindow ?: return

        val isShortsNow = isYoutubeShorts(root)

        if (isShortsNow && !inShorts) {
            inShorts = true
            startTime = System.currentTimeMillis()
            startTimer()
        }

        if (!isShortsNow && inShorts) {
            stopTimer()
            inShorts = false
            startTime = 0L
        }
    }

    override fun onInterrupt() {}

    private fun startTimer() {
        if (checkerRunning) return
        checkerRunning = true
        handler.post(checkRunnable)
    }

    private fun stopTimer() {
        checkerRunning = false
        handler.removeCallbacks(checkRunnable)
    }

    private val checkRunnable = object : Runnable {
        override fun run() {
            if (!checkerRunning) return

            val elapsed = System.currentTimeMillis() - startTime
            if (elapsed >= MAX_TIME_MS) {
                blockYoutube()
                return
            }

            handler.postDelayed(this, 200)
        }
    }

    private fun isYoutubeShorts(root: AccessibilityNodeInfo): Boolean {

        val hasShortLabel = root.findAny {
            it.contentDescription?.contains("Short", ignoreCase = true) == true ||
                    it.text?.toString()?.contains("Short", ignoreCase = true) == true
        }

        val hasSeekBar = root.findAny {
            it.className == "android.widget.SeekBar"
        }

        return hasShortLabel && hasSeekBar
    }

    private fun AccessibilityNodeInfo.findAny(
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): Boolean {
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(this)

        while (stack.isNotEmpty()) {
            val node = stack.removeLast()
            if (predicate(node)) return true

            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { stack.add(it) }
            }
        }
        return false
    }

    private fun blockYoutube() {
        stopTimer()
        inShorts = false
        startTime = 0L
        performGlobalAction(GLOBAL_ACTION_HOME)
        Toast.makeText(this, "Tiempo de Shorts terminado 😅", Toast.LENGTH_SHORT).show()
    }
}
