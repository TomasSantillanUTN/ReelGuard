package com.example.pruebareel

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class ReelBlockerService : AccessibilityService() {

    private val MAX_REELS = 5
    private var reelCount = 0
    private var inReelViewer = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.packageName != "com.instagram.android") return

        val root = rootInActiveWindow ?: return

        // Detectamos si estamos realmente en REEL pantalla completa
        inReelViewer = isFullScreenReel(event, root)

        when (event.eventType) {

            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                if (inReelViewer) {
                    reelCount++

                    if (reelCount >= MAX_REELS) {
                        blockInstagram()
                    }
                }
            }

            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                if (!inReelViewer) {
                    reelCount = 0
                }
            }
        }
    }

    override fun onInterrupt() {}

    /**
     * SOLO cuenta reels cuando:
     *  1️⃣ El evento viene del ViewPager (pantalla completa)
     *  2️⃣ Hay un "Reel de ..." en la UI
     */
    private fun isFullScreenReel(
        event: AccessibilityEvent,
        root: AccessibilityNodeInfo
    ): Boolean {

        val srcClass = event.source?.className?.toString() ?: ""

        val fromViewPager =
            srcClass.contains("ViewPager", ignoreCase = true)

        if (!fromViewPager) return false

        val hasReelLabel = root.findAny {
            val desc = it.contentDescription?.toString() ?: return@findAny false
            desc.startsWith("Reel de ")
        }

        return hasReelLabel
    }

    /**
     * DFS genérico
     */
    private fun AccessibilityNodeInfo.findAny(
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): Boolean {
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(this)

        while (stack.isNotEmpty()) {
            val node = stack.removeLast()
            if (predicate(node)) return true

            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { stack.add(it) }
            }
        }
        return false
    }

    /**
     * Acción final
     */
    private fun blockInstagram() {
        reelCount = 0
        performGlobalAction(GLOBAL_ACTION_HOME)
        Toast.makeText(this, "Basta de Reels por ahora 😅", Toast.LENGTH_SHORT).show()
    }
}
