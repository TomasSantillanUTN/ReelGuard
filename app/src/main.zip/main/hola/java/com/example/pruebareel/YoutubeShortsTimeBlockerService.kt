package com.example.pruebareel

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class YoutubeShortsTimeBlockerService : AccessibilityService() {

    private val MAX_TIME_MS = 5_000L   // <- cambiás esto y listo

    private var inShorts = false
    private var startTime = 0L
    private val handler = Handler(Looper.getMainLooper())
    private var timerRunning = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.packageName != "com.google.android.youtube") return

        val root = rootInActiveWindow ?: return

        val nowInShorts = isShortsScreen(root)

        if (nowInShorts && !inShorts) {
            inShorts = true
            startTime = System.currentTimeMillis()
            startTimer()
        }

        if (!nowInShorts && inShorts) {
            stopTimer()
            inShorts = false
        }
    }

    override fun onInterrupt() {}

    private fun isShortsScreen(root: AccessibilityNodeInfo): Boolean {
        val hasShortsText = root.findAny {
            it.text?.toString()?.contains("Shorts", true) == true ||
                    it.contentDescription?.toString()?.contains("Shorts", true) == true
        }

        val hasSeekBar = root.findAny {
            it.className == "android.widget.SeekBar"
        }

        return hasShortsText || hasSeekBar
    }

    private fun AccessibilityNodeInfo.findAny(
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): Boolean {
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(this)

        while (stack.isNotEmpty()) {
            val node = stack.removeLast()
            if (predicate(node)) return true

            for (i in 0 until node.childCount) {
                node.getChild(i)?.let(stack::add)
            }
        }
        return false
    }

    private fun startTimer() {
        if (timerRunning) return
        timerRunning = true

        handler.postDelayed({
            if (inShorts) blockYoutube()
        }, MAX_TIME_MS)
    }

    private fun stopTimer() {
        timerRunning = false
        handler.removeCallbacksAndMessages(null)
    }

    private fun blockYoutube() {
        stopTimer()
        inShorts = false
        performGlobalAction(GLOBAL_ACTION_HOME)
        Toast.makeText(this, "Tiempo de Shorts terminado 😅", Toast.LENGTH_SHORT).show()
    }
}
