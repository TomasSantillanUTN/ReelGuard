package com.example.pruebareel

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class ReelBlockerService : AccessibilityService() {

    private val MAX_REELS = 5
    private var reelCount = 0
    private var inReelViewer = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.packageName != "com.instagram.android") return

        val root = rootInActiveWindow ?: return

        inReelViewer = isFullscreenReel(event, root)

        when (event.eventType) {

            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                if (inReelViewer) {
                    reelCount++

                    if (reelCount >= MAX_REELS) {
                        blockInstagram()
                    }
                }
            }

            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                if (!inReelViewer) {
                    reelCount = 0
                }
            }
        }
    }

    override fun onInterrupt() {}

    /**
     * Detecta si estamos en un reel pantalla completa real.
     * Regla:
     *  - El scroll debe venir de ViewPager (pantalla completa)
     *  - Debe haber un Reel real en UI (seekbar o descripción Reel de XXX)
     */
    private fun isFullscreenReel(
        event: AccessibilityEvent,
        root: AccessibilityNodeInfo
    ): Boolean {

        val isViewPager =
            event.source?.className?.toString()?.contains("ViewPager", ignoreCase = true) == true

        if (!isViewPager) return false

        val hasSeekBar = root.findAny { it.className == "android.widget.SeekBar" }

        val hasReelDescription = root.findAny {
            it.contentDescription?.toString()?.startsWith("Reel de") == true
        }

        return hasSeekBar || hasReelDescription
    }

    /**
     * DFS genérico
     */
    private fun AccessibilityNodeInfo.findAny(
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): Boolean {
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(this)

        while (stack.isNotEmpty()) {
            val node = stack.removeLast()
            if (predicate(node)) return true

            for (i in 0 until node.childCount) {
                node.getChild(i)?.let(stack::add)
            }
        }
        return false
    }

    private fun blockInstagram() {
        reelCount = 0
        performGlobalAction(GLOBAL_ACTION_HOME)
        Toast.makeText(this, "Basta de Reels por ahora 😅", Toast.LENGTH_SHORT).show()
    }
}
